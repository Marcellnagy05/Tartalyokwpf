﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Osztalyaim;
namespace Tartalyok
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Osztalyaim.Tartaly> tartalyok = new List<Tartaly>();
        public MainWindow()
        {
            InitializeComponent();
            rdoTeglatest.IsChecked = true;
        }
        private void rdoTeglatest_Checked(object sender, RoutedEventArgs e)
        {
            txtAel.Text = "";
            txtBel.Text = "";
            txtCel.Text = "";
            txtAel.IsEnabled = true;
            txtBel.IsEnabled = true;
            txtCel.IsEnabled = true;
        }

        private void rdoKocka_Checked(object sender, RoutedEventArgs e)
        {
            txtAel.Text = "10";
            txtBel.Text = "10";
            txtCel.Text = "10";
            txtAel.IsEnabled = false;
            txtBel.IsEnabled = false;
            txtCel.IsEnabled = false;
        }

        private void btnFelvesz_Click(object sender, RoutedEventArgs e)
        {
            Tartaly ujTest;
            if (rdoKocka.IsChecked == true)
            {
                ujTest = new Tartaly(txtNev.Text);
            }
            else { ujTest = new Tartaly(txtNev.Text, Convert.ToInt32(txtAel.Text), Convert.ToInt32(txtBel.Text), Convert.ToInt32(txtCel.Text)); }

            if (txtNev.Text == "")
            {
                MessageBox.Show("Adjon meg nevet!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                lbTartalyok.Items.Add(ujTest.Info());
                tartalyok.Add(ujTest);
            }
        }

        private void btnRogzit_Click(object sender, RoutedEventArgs e)
        {
            StreamWriter sw = new StreamWriter("tartalyok.csv", append: true);
            foreach (Tartaly item in tartalyok)
            {
                String csvsor = $"{item.Nev};{item.aEl};{item.bEl};{item.cEl},{item.AktLiter}";
                sw.WriteLine(csvsor);
            }
            sw.Close();
        }

        private void btnDuplaz_Click(object sender, RoutedEventArgs e)
        {
            if (lbTartalyok.SelectedIndex == -1)
            {
                MessageBox.Show("Nem választott ki semmit!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                tartalyok[lbTartalyok.SelectedIndex].DuplazMeretet();
                lbTartalyok.Items[lbTartalyok.SelectedIndex] = tartalyok[lbTartalyok.SelectedIndex].Info();
            }
        }

        private void btnLeenged_Click(object sender, RoutedEventArgs e)
        {
            if (lbTartalyok.SelectedIndex == -1)
            {
                MessageBox.Show("Nem választott ki semmit!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                tartalyok[lbTartalyok.SelectedIndex].TeljesLeengedes();
                lbTartalyok.Items[lbTartalyok.SelectedIndex] = tartalyok[lbTartalyok.SelectedIndex].Info();
            }
        }

        private void btntolt_Click(object sender, RoutedEventArgs e)
        {
            if (lbTartalyok.SelectedIndex == -1)
            {
                MessageBox.Show("Nem választott ki semmit!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                tartalyok[lbTartalyok.SelectedIndex].Tolt(Convert.ToDouble(txtMennyitTolt.Text));
                lbTartalyok.Items[lbTartalyok.SelectedIndex] = tartalyok[lbTartalyok.SelectedIndex].Info();
            }
        }
    }
}
